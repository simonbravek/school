# TODO
- [x] backend testy
- [x] frontend testy
- [x] přemýšlet o stránce
- [x] vymyslet jak bude fungovat vyhledaváč
*jednoduché to nebude :(*
- [ ] vymyslet co napsat do todo


# Nápady
- qr kódy na kontaky
import datetime
import json
import os
from hashlib import sha256
from icalendar import Calendar, Event, vCalAddress, vText
import re
from base64 import b64encode

from flask import Flask, render_template, request, session, abort, redirect, send_file
from flask_restful import Api, Resource
from . import db
from . import logger
from . import config
from . import utils

app = Flask(__name__)
api = Api(app)

app.config.from_object(config.BaseConfig)
app.config.from_mapping(
    DATABASE=os.path.join(app.instance_path, 'tourdeflask.sqlite'),
)

SERVER_URL = "http://a89173e8843d9da4.app.tourdeapp.cz"
PAGE_RETURN_CARDS = 17


# ensure the instance folder exists
try:
    os.makedirs(app.instance_path)
except OSError:
    pass

db.init_app(app)
logger.init()

@app.route('/')
def hello_world():  # put application's code here
    return render_template("index.html")

@app.route("/snake")
def snake():
    return render_template("lol.html")

@app.route("/lecturer/<uuid>")
def lecturer_view(uuid):
    lecturer = db.get_lecturer(uuid)

    if lecturer[1] == 404:
        return render_template("404.html")

    return render_template("lecturer.html", lecturer = lecturer[0])

# ERRORS
@app.errorhandler(404)
def not_found(e):
    return render_template("404.html")


@app.errorhandler(403)
def forbiden(e):
    return render_template("403.html")


@app.errorhandler(500)
def internal_server_error(e):
    return render_template("500.html")


@app.route("/testbooking", methods=["GET"])
def testbooking():
    return render_template("test_booking.html")

# USER
@app.route("/dashboard", methods=["GET"])
def user():
    if 'user' not in session:
        return redirect("/login")

    lecturer, state = db.get_lecturer_by_id(session['user']['lecturer'])
    lecturer_fullname = utils.get_lecturer_fullname(lecturer)

    return render_template("dashboard.html", user=session['user'], lecturer_fullname=lecturer_fullname)

@app.route("/calendar")
def calendar():
    """
    WARNING THIS IS SUPER UGLY NO TIME TO FIX
    :return:
    """

    if 'user' in session and session['user']['lecturer'] is not None:
        lecturer, state = db.get_lecturer_by_id(session['user']['lecturer'])
        hours = db.get_lecturer_hours(session['user']['lecturer'])
        cal = Calendar()
        nowtime = datetime.datetime.now().strftime("%Y-%m-%d")

        cal['summary'] = f'Plan Výuky - {nowtime}'
        cal.add("prodid", "TeacherDigitalAgency//LektorKalendarExport")
        cal.add("prodid", "TeacherDigitalAgency//LektorKalendarExport")
        cal.add("version", "2.0")

        for hour in hours:
            hour['time'] = datetime.datetime.fromisoformat(hour['time'].split(".")[0])
            hour['time'].replace(tzinfo=datetime.timezone.utc)

        # FIND OLDEST AND NEWEST TIME
        if len(hours) > 0:
            oldest_time = hours[0]['time']
            newest_time = hours[0]['time'] + datetime.timedelta(hours=1)

            for hour in hours:
                if not hour['confirmed'] or hour['phone'] == "-": continue
                if hour['time'] < oldest_time:
                    oldest_time = hour['time']

                if (hour['time'] + datetime.timedelta(hours=1)) > newest_time:
                    newest_time = hour['time'] + datetime.timedelta(hours=1)

            cal.add("dtstart", oldest_time)
            cal.add("dtend", newest_time)

        # ORGANISER
        organiser_email = "proc.lektor.nema.email@tda.cz"

        if 'emails' in lecturer["contact"] and len(lecturer["contact"]["emails"]) > 0:
            organiser_email = lecturer["contact"]["emails"][0]

        organizer = vCalAddress(f'MAILTO:{organiser_email}')

        lecturer_fullname = utils.get_lecturer_fullname(lecturer)

        organizer.params['cn'] = vText(lecturer_fullname)
        organizer.params['role'] = vText('Lektor')


        for hour in hours:
            if not hour['confirmed'] or hour['phone'] == "-": continue
            event = Event()
            typ_hodiny = ["Online", "Osobně"][hour['type'] - 1]
            jmeno = f"{hour['first_name']} {hour['last_name']}"

            attendee = vCalAddress(f"MAILTO:{hour['email']}")
            attendee.params['cn'] = vText(jmeno)
            attendee.params['ROLE'] = vText('Student')

            event['organizer'] = organizer

            event.add('ATENDEE', attendee, encode=0)
            event.add("summary", f"Hodina - {jmeno}")
            event.add("dtstart", hour['time'])
            event.add("uid", hour['uuid'])
            event.add("dtstamp", hour['time'])
            event.add("dtend", hour['time'] + datetime.timedelta(hours=1))
            event.add("DESCRIPTION", hour['message'])

            event.add("location", typ_hodiny)
            cal.add_component(event)

        with open(f"./app/temp_cal.ical", "wb") as f:
            f.write(cal.to_ical())


        return send_file("temp_cal.ical", "text/calendar", download_name = f"{nowtime}_plan_vyuky.ical")

        #return send_file(cal.to_ical(), "text/calendar")
    else:
        abort(403)

#           _____ _____
#     /\   |  __ \_   _|
#    /  \  | |__) || |
#   / /\ \ |  ___/ | |
#  / ____ \| |    _| |_
# /_/    \_\_|   |_____|
@app.route("/api")
def api_tester():
    return render_template("api_tester.html")


@app.route("/log")
def log():
    return logger.get()


class Lecturers(Resource):
    def post(self):
        # API AUTHORIZATION CHECK
        logger.log(f"------------POST LECTURER---------------------<br>{request.url}<br>---------------------------------")
        auth, state = auth_request_check(request.authorization)
        if auth is not None: return auth, state
        #
        data_json = request.get_json()

        check = data_key_check(data_json, ['username', 'password'])
        if check is not None: return check, 400

        lecturer_data, code = db.create_new_lecturer(data_json)

        db.create_user(data_json['username'], sha256(data_json['password'].encode('utf-8')).hexdigest(), lecturer_data['rowid'])

        lecturer_data.pop('rowid')

        return lecturer_data

    def get(self):
        # logger.log(f"---------------------------------<br>{request.url}<br>---------------------------------")
        # logger.log("ete?")
        return db.get_lecturers()

    def delete(self):
        # API AUTHORIZATION CHECK
        logger.log(f"---------------------------------<br>{request.url}<br>---------------------------------")
        auth, state = auth_request_check(request.authorization)
        if auth is not None: return auth, state
        #
        db.drop_tables()
        db.setup_tables()
        return {}, 204


class Lecturer(Resource):
    def get(self, uuid):
        # logger.log(f"---------------------------------<br>{request.url}<br>---------------------------------")
        return db.get_lecturer(uuid)

    def put(self, uuid):
        logger.log(f"PUT DATA! {request.get_json()}")
        # API AUTHORIZATION CHECK
        auth, state = auth_request_check(request.authorization)
        if auth is not None: return auth, state
        #
        data = request.get_json()

        # update user data if needed
        check = data_key_check(data, ['username', 'password'])
        if check is None:
            db.update_user(db.get_user_from_lecturer(uuid)[-1], data)




        # logger.log(f"---------------------------------<br>{request.url}")
        # logger.log(f"{request.args}")
        # logger.log(f"{str(data)}<br>---------------------------------")
        return db.update_lecturer(uuid, data)

    def delete(self, uuid):
        logger.log(f"-------------------DELETE--------------<br>{request.url}<br>---------------------------------")
        # API AUTHORIZATION CHECK
        auth, state = auth_request_check(request.authorization)
        if auth is not None: return auth, state
        #
        db.delete_user(db.get_user_from_lecturer(uuid)[-1])

        logger.log(f"---------------------------------<br>{request.url}<br>---------------------------------")
        return db.delete_lecturer(uuid)


class SearchUtils(Resource):
    def get(self):
        data = {
            "locations": db.get_all_locations(),
            "tags": db.get_all_tags(),
            "price_range": db.get_price_range()
        }



        return data

class Search(Resource):
    def post(self):
        data = request.get_json()

        for key in ['location', 'tags', 'pay_min', 'pay_max']:
            if key not in data:
                data[key] = None


        lecturer_shuffle = db.get_search_lecturers_shuffle(data['location'], data['tags'], data['pay_min'], data['pay_max'])

        page_0 = lecturer_shuffle[0:min(len(lecturer_shuffle), PAGE_RETURN_CARDS)]

        lecturers_page_0 = db.search_lecturers(page_0)

        return {'search' : lecturers_page_0, 'shuffle' : lecturer_shuffle}, 200


class SearchPage(Resource):
    def post(self):
        data = request.get_json()

        if 'rowids' not in data:
            return {}, 400


        search = db.search_lecturers(data['rowids'])

        return search, 200



api.add_resource(Lecturers, "/api/lecturers")
api.add_resource(Lecturer, "/api/lecturers/<uuid>")
api.add_resource(SearchUtils, "/api/searchutils")
api.add_resource(Search, "/api/search")
api.add_resource(SearchPage, "/api/getpage")

@app.route("/api/hour", methods=['GET', 'POST'])
def api_hour():
    data = json.loads(request.get_data())

    check = data_key_check(data, ["uuid", "datetime", "hour_type", "first_name", "last_name", "email", "phone", "message"])
    if check is not None: return check, 400
    # check if data is valid
    if not re.search(utils.EMAIL_SEARCH_REGEX, data['email']):
        return "Napište validní email", 400
    if not re.search(utils.PHONE_SEARCH_REGEX, data['phone']):
        return "Napište validní telefon", 400

    # add hour
    hour_uuid = db.add_lecturer_hour(data['uuid'], data['datetime'], data['hour_type'], data['first_name'], data['last_name'], data['email'], data['phone'], data['message'])

    # create confirmation link
    confirm_id = db.add_to_confirmation_queue({
        "type": "HOUR",
        "uuid": hour_uuid,
        "datetime": data['datetime']
    })

    # send email
    dt = datetime.datetime.fromisoformat(data['datetime'].split(".")[0])
    dt += datetime.timedelta(hours=1) # CHANGE TIMEZONE # UGLY I KNOW

    utils.send_email_gmail(
        "Potvrďte rezervaci",
        render_template("email/hour_reserve_confirm.html", confirm_url = f"{SERVER_URL}/confirm/{confirm_id}", datetime = dt.strftime("%d. %m. %y, %H:%M")),
        data['email']
    )

    return "ok", 200


@app.route("/api/gethours", methods=['POST'])
def api_get_hours():
    data = json.loads(request.get_data())
    db.clean_up_confirmation_queue()

    check = data_key_check(data, ["uuid", "start_date", "end_date"])
    if check is not None: return check, 400

    hours = db.get_lecturer_hours(data['uuid'], data['start_date'], data['end_date'])
    # if user not existant return bad request
    if hours is dict: return hours, 404

    #
    return hours, 200

@app.route("/api/blockhour", methods=['POST'])
def api_block_hour():
    if 'user' in session and session['user']['lecturer'] is not None:
        data = json.loads(request.get_data())

        check = data_key_check(data, ["datetime"])
        if check is not None: return check, 400

        db.add_lecturer_hour(session['user']['lecturer'], data['datetime'], 1, "-", "-", "-", "-", "-", True)

        return "ok", 200
    else:
        abort(403)

@app.route("/api/cancelhour", methods=['POST'])
def api_delete_hour():
    if 'user' in session and session['user']['lecturer'] is not None:
        data = json.loads(request.get_data())

        check = data_key_check(data, ["uuid"])
        if check is not None: return check, 400

        hour = db.delete_lecturer_hour(session['user']['lecturer'], data['uuid'])
        if type(hour) is str: return hour, 404

        # CHECK IF DELETED HOUR IS A LECTURER BLOCKED HOUR - IF YES, DON'T SEND EMAIL AND CONTINUE
        if hour['phone'] == "-":
            return "deleted", 200

        hour['time'] = datetime.datetime.fromisoformat(hour['time'].split(".")[0])
        hour['time'] += datetime.timedelta(hours=1) # CHANGE TIMEZONE # UGLY I KNOW
        hour['time'] = hour['time'].strftime("%d. %m. %y, %H:%M")

        utils.send_email_gmail(
            "Rezervace zrušena",
            render_template("email/reservation_canceled.html", hour=hour, message = data['message'].replace("\n", "<br>")),
            hour['email']
        )

        return "deleted", 200
    else:
        abort(403)

# REGISTRATION
@app.route("/confirm/<uuid>", methods=['GET'])
def api_confirm_user_creation(uuid):
    result, status = db.confirm_registration(uuid)

    if status == 404:
        abort(404)

    message = "Potvrzeno!"


    if result['type'] == "HOUR":
        message = "Lekce potvrzena!"

        # send email
        hour, state = db.get_hour(result['uuid'])

        hour['time'] = datetime.datetime.fromisoformat(hour['time'].split(".")[0])
        hour['time'] += datetime.timedelta(hours=1) # CHANGE TIMEZONE # UGLY I KNOW
        hour['time'] = hour['time'].strftime("%d. %m. %y, %H:%M")

        lecturer, state = db.get_lecturer_by_id(hour['lecturer'])

        if 'emails' in lecturer["contact"]:
            for email in lecturer["contact"]["emails"]:
                utils.send_email_gmail(
                    "Nová lekce objednána",
                    render_template("email/new_lecture.html", hour=hour),
                    email
                )


    return render_template("confirmed.html", message=message)

# LOGING IN
@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        data = json.loads(request.get_data())

        # check if request valid
        check = data_key_check(data, ['username', 'password'])
        if check is not None: return check, 400
        # auth check
        user, status = db.authenticate_user(data['username'], data['password'])

        if status != 200:
            return user, status

        session['user'] = user
        session['user']['is_authenticated'] = True
    elif request.method == "GET":
        return render_template("login.html")

    return "Přihlášení úspěšné", 200


@app.route("/logout", methods=["GET"])
def logout():
    if 'user' not in session:
        return redirect("/login")

    session.pop('user')
    return redirect("/login")


def data_key_check(data, keys):
    for key in keys:
        if key not in data:
            return {"status": 400, "message": f"missing {key}"}

def auth_request_check(auth):
    # STUPID I KNOW
    # BUT FOR NOW HARD CODED LOGIN
    # PLS NOBODY LOOK AT THIS SOURCE CODE
    logger.log("AUTH START")

    if auth is None:
        logger.log("AUTH NO HEADER")
        return {"status": "add basic auth header", "code": 400}, 400

    auth_params = auth.parameters


    result = data_key_check(auth_params, ['username', 'password'])
    if result is not None:
        logger.log("BAD PARAMS " + str(result))
        return result, 400

    if auth_params['username'] != app.config['ADMIN_USERNAME'] or (auth_params['password'] != app.config['ADMIN_PASSWORD']):# and auth_params['password'] != "wrongPass"):
        logger.log("NO PASS")
        return {"status": 401, 'message': 'unauthorized'}, 401

    return None, 200


#   _____ _______       _____ _______
#  / ____|__   __|/\   |  __ \__   __|
# | (___    | |  /  \  | |__) | | |
#  \___ \   | | / /\ \ |  _  /  | |
#  ____) |  | |/ ____ \| | \ \  | |
# |_____/   |_/_/    \_\_|  \_\ |_|
if __name__ == '__main__':
    app.run(debug = True)

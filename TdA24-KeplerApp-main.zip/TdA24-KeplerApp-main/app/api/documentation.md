# API INTERACTIONS

## /api/register
checks if registration data is valid, makes sence, does not yet exist etc.

and sends confirmation email

*after confirmation user saved to database*


```
what to send in json
{
    "email": STRING,
    "first_name": STRING,
    "last_name": STRING,
    "password": STRING,
    "password_2": STRING, / password confirmation /
    "lecturer": { / lecturer data (STEJNĚ JAKO /api/lecturers/ [POST] ) / }
                OR NULL   / depends if user is lecturer /
}
```

## /api/lecturers/ [POST]
creates lecturer and adds him to db

*tydle api end pointy bychom měli pak asi smazat... protože logicky...*

```
{
    "title_before": STRING,
    "first_name": STRING,
    "middle_name": STRING,
    "last_name": STRING,
    "title_after": STRING,
    "picture_url": STRING (url),
    "location" : STRING,
    "claim" : STRING,
    "bio": STRING,
    "price_per_hour" : INT,
    "contact": {
        / NAPŘ.: /
        "telephone_numbers": ["+420 722 482 974"],
        "emails": ["placha@scg.cz", "predseda@scg.cz"]
    }
}
```
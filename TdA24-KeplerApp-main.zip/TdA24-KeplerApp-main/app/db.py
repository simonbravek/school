import json
import random

import click
from flask import current_app, g
from flask.cli import with_appcontext
from uuid import uuid4
from . import logger, utils

import sqlite3
import re
from hashlib import sha256



LECTURER_TABLE_VALUES = ["title_before", "first_name", "middle_name", "last_name", "title_after", "picture_url", "location", "claim", "bio", "price_per_hour", "contact"]
LECTURER_TABLE_VALUES_MANDATORY = ["first_name", "last_name"]


# SETUP
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(
            current_app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES,
            check_same_thread=False
        )
        #g.db.row_factory = sqlite3.Row

    return g.db


def get_db_cur():
    if 'db_cur' not in g:
        g.db_cur = get_db().cursor()

    return g.db_cur


def close_db_cur(e = None):
    db_cur = g.pop('db_cur', None)

    if db_cur is not None:
        db_cur.close()

def close_db(e=None):
    db = g.pop('db', None)

    if db is not None:
        db.close()


def init_db():
    """
    Inicializuje databázi dle schema.sql
    """
    db = get_db()

    with current_app.open_resource('schema.sql') as f:
        db.executescript(f.read().decode('utf8'))

    #drop_tables()
    setup_tables()


def drop_tables():
    get_db_cur().execute("""DROP TABLE IF EXISTS lecturers""")
    get_db_cur().execute("""DROP TABLE IF EXISTS lecturers_tags""")
    get_db_cur().execute("""DROP TABLE IF EXISTS tags""")
    get_db_cur().execute("""DROP TABLE IF EXISTS users""")
    get_db_cur().execute("""DROP TABLE IF EXISTS confirmation_queue""")
    get_db_cur().execute("""DROP TABLE IF EXISTS hour_types""")
    get_db_cur().execute("""DROP TABLE IF EXISTS hours""")
    get_db().commit()

def setup_tables():
    # ENABLE FOREIGN KEYS
    get_db_cur().execute("""PRAGMA foreign_keys = ON""")
    # LECTURERS
    get_db_cur().execute("""CREATE TABLE IF NOT EXISTS lecturers(
        uuid TEXT,
        title_before VARCHAR(255),
        first_name VARCHAR(255) NOT NULL,
        middle_name VARCHAR(255),
        last_name VARCHAR(255) NOT NULL,
        title_after VARCHAR(255),
        picture_url TEXT,
        location VARCHAR(255),
        claim TEXT,
        bio TEXT,
        price_per_hour INT,
        contact TEXT,
        PRIMARY KEY(uuid)
    )""")

    #
    get_db_cur().execute("""CREATE TABLE IF NOT EXISTS tags(
        uuid TEXT,
        name TEXT NOT NULL,
        PRIMARY KEY(uuid)
    )""")

    get_db_cur().execute("""CREATE TABLE IF NOT EXISTS lecturers_tags(
        lecturer_rowid INT,
        tag_rowid INT
        /*FOREIGN KEY(lecturer_rowid) REFERENCES lecturers(ROWID),
        FOREIGN KEY (tag_rowid) REFERENCES tags(ROWID)*/
    )""")

    # USERS
    get_db_cur().execute("""CREATE TABLE IF NOT EXISTS users(
        username TEXT NOT NULL,
        password VARCHAR(255) NOT NULL,
        lecturer_rowid INT
        /*FOREIGN KEY(lecturer_rowid) REFERENCES lecturers(ROWID)*/
    )""")

    get_db_cur().execute("""CREATE TABLE IF NOT EXISTS confirmation_queue(
        confirm_id VARCHAR(255) NOT NULL,
        time_sent VARCHAR(255) DEFAULT CURRENT_TIMESTAMP,
        data TEXT NOT NULL
    )""")

    get_db_cur().execute("""CREATE TABLE IF NOT EXISTS hour_types(
        name TEXT NOT NULL
    )""")

    get_db_cur().execute("""CREATE TABLE IF NOT EXISTS hours(
        uuid TEXT NOT NULL,
        datetime VARCHAR(255),
        lecturer_rowid INT,
        hour_type INT,
        student_first_name VARCHAR(255) NOT NULL,
        student_last_name VARCHAR(255) NOT NULL,
        student_email VARCHAR(255) NOT NULL,
        student_phone_number VARCHAR(255) NOT NULL,
        student_message TEXT,
        confirmed INT DEFAULT FALSE
    )""")

    get_db_cur().execute("""SELECT * FROM lecturers""")
    get_db().commit()


#  _    _  _____ ______ _____   _____
# | |  | |/ ____|  ____|  __ \ / ____|
# | |  | | (___ | |__  | |__) | (___
# | |  | |\___ \|  __| |  _  / \___ \
# | |__| |____) | |____| | \ \ ____) |
#  \____/|_____/|______|_|  \_\_____/

def create_user(username, password_hash, lecturer):
    get_db_cur().execute("INSERT INTO users(username, password, lecturer_rowid) VALUES (?, ?, ?)", (username, password_hash, lecturer))
    get_db().commit()

def register_user(email, first_name, last_name, password, password_2, lecturer = None):
    message, check = register_user_check(email, first_name, last_name, password, password_2)
    if not check:
        return message, 400

    lecturer_id = None

    # lecturer creation
    if lecturer is not None:
        check, status = create_lecturer_check(lecturer)

        if status == 400:
            return check, status


    password_hash = sha256(password.encode('utf-8')).hexdigest()

    safe_keep_data = json.dumps({"email": email, "first_name": first_name, "last_name": last_name, "hash": password_hash, "lecturer": lecturer})
    clean_up_confirmation_queue()

    confirm_id = str(uuid4()).replace("-", "")

    get_db_cur().execute("INSERT INTO confirmation_queue(confirm_id, data, time_sent) VALUES (?, ?, datetime('now'))", (confirm_id, safe_keep_data))
    get_db().commit()

    print(confirm_id)
    return confirm_id, 200

def clean_up_confirmation_queue():
    # remove hours that are old
    get_db_cur().execute("SELECT data FROM confirmation_queue WHERE datetime('now') >= datetime(time_sent, '+1 Hour')")
    to_remove = get_db_cur().fetchall()
    #
    for data in to_remove:
        if json.loads(data[0])['type'] == "HOUR":
            get_db_cur().execute("DELETE FROM hours WHERE uuid = ?", (json.loads(data[0])['uuid'],))

    #
    get_db_cur().execute("DELETE FROM confirmation_queue WHERE datetime('now') >= datetime(time_sent, '+1 Hour')")
    get_db().commit()


def add_to_confirmation_queue(data):
    confirm_id = str(uuid4()).replace("-", "")
    get_db_cur().execute("INSERT INTO confirmation_queue(confirm_id, data, time_sent) VALUES (?, ?, datetime('now'))", (confirm_id, json.dumps(data)))
    get_db().commit()

    return confirm_id


def register_user_check(email, first_name, last_name, password, password_2):
    # password checks
    if password != password_2:
        return "Hesla se neshodují", False

    if password == "":
        return "Heslo je prázdné", False

    if len(password) < 8:
        return "Heslo je moc krátké", False

    if len(password) > 32:
        return "Heslo je moc dlouhé", False

    # name check
    if first_name == "":
        return "Napište křestní jméno", False

    if last_name == "":
        return "Napište příjmení", False

    # email check
    if not re.search(utils.EMAIL_SEARCH_REGEX, email):
        return "Napište validní email", False

    get_db_cur().execute("SELECT 1 FROM users WHERE email = ?", (email,))
    if len(get_db_cur().fetchall()) > 0: return "Tento email už je zaregistrován", False

    return "Jde to", True

def authenticate_user(username, password):
    password_hash = sha256(password.encode('utf-8')).hexdigest()

    get_db_cur().execute("SELECT *, ROWID FROM users WHERE username = ? and password = ?", (username, password_hash))

    data = get_db_cur().fetchall()
    if len(data) == 0:
        return "Email nebo heslo špatně", 400

    return format_user_data(data[0]), 200


def update_user(user_rowid, new_data):
    # add all changed values to be ? into mega query
    value_pairs = ()
    qmarks = ""

    if 'password' in new_data:
        new_data['password'] = sha256(new_data['password'].encode('utf-8')).hexdigest()

    for key in new_data.keys():
        if key in ['username', 'password']:
            qmarks += f"{key} = ?, "
            #value_pairs += (key,)
            value_pairs += (new_data[key],)


    # add user_id for search
    value_pairs += (user_rowid,)


    if qmarks != "":
        qmarks = qmarks[:-2]

        get_db_cur().execute(f"""
        UPDATE users
        SET {qmarks}
        WHERE ROWID = ?""", value_pairs)
        get_db().commit()


    return 200

def delete_user(user_rowid):
    get_db_cur().execute("DELETE FROM users WHERE ROWID = ?", user_rowid)
    get_db().commit()

def get_user_from_lecturer(lecturer_uuid):
    get_db_cur().execute("SELECT ROWID FROM lecturers WHERE uuid = ?", (lecturer_uuid, ))

    get_db_cur().execute("SELECT *, ROWID FROM users")

    get_db_cur().execute("""
        SELECT username, lecturers.rowid
        FROM users
        JOIN lecturers
        ON lecturers.uuid = ? and lecturers.rowid = users.lecturer_rowid
    """, (lecturer_uuid,))

    data = get_db_cur().fetchall()

    if len(data) == 0:
        return "No lecturer with this uuid"

    return data[0]



def confirm_registration(confirm_id):
    clean_up_confirmation_queue()
    get_db_cur().execute("SELECT * FROM confirmation_queue WHERE confirm_id = ?", (confirm_id, ))
    confirmations = get_db_cur().fetchall()

    if len(confirmations) > 0:
        data = json.loads(confirmations[0][2])

        get_db_cur().execute("DELETE FROM confirmation_queue WHERE confirm_id = ?", (confirm_id, ))
        get_db().commit()

        # DIFFER FROM DIFFERENT CONFIRMATIONS
        if data['type'] == "USER":
            create_user(data['username'], data['hash'], data['lecturer'])
            return data, 200
        elif data['type'] == "HOUR":
            print(data['uuid'])
            # CONFIRM HOUR
            get_db_cur().execute("UPDATE hours SET confirmed = TRUE WHERE uuid = ?", (data['uuid'],))
            get_db().commit()
            return data, 200


    else:
        return "not-found", 404

# UTILS
def format_user_data(raw_data):
    return {
        "username": raw_data[0],
        "lecturer": raw_data[2]
    }

#  _    _  ____  _    _ _____   _____
# | |  | |/ __ \| |  | |  __ \ / ____|
# | |__| | |  | | |  | | |__) | (___
# |  __  | |  | | |  | |  _  / \___ \
# | |  | | |__| | |__| | | \ \ ____) |
# |_|  |_|\____/ \____/|_|  \_\_____/


def format_hour_data(raw_data):
    return {
        "uuid": raw_data[0],
        "time": raw_data[1],
        "type": raw_data[3],
        "lecturer": raw_data[2],
        "first_name": raw_data[4],
        "last_name": raw_data[5],
        "email": raw_data[6],
        "phone": raw_data[7],
        "message": raw_data[8],
        "confirmed": raw_data[9] == 1
    }


def get_lecturer_hours(uuid, start_date = None, end_date = None):
    # if uuid is an int => probably lecturer_id already :D
    if type(uuid) is not int:
        lecturer_id = get_lecturer_id(uuid)
        if type(lecturer_id) is not int: return lecturer_id
    else:
        lecturer_id = uuid

    print(lecturer_id)

    query = "SELECT * FROM hours WHERE lecturer_rowid = ?"
    params = (lecturer_id, )
    #
    if start_date is not None:
        query += "and datetime >= ?"
        params += (start_date,)

    #
    if end_date is not None:
        query += " and datetime <= ?"
        params += (end_date,)

    #
    get_db_cur().execute(query, params)
    
    hours = get_db_cur().fetchall()

    # format data
    for i in range(len(hours)):
        hours[i] = format_hour_data(hours[i])

    return hours

def get_hour(uuid):
    get_db_cur().execute("SELECT * FROM hours WHERE uuid = ?", (uuid,))

    data = get_db_cur().fetchall()
    if len(data) == 0:
        return "not found", 404

    return format_hour_data(data[0]), 200


def add_lecturer_hour(uuid, datetime, hour_type, student_first_name, student_last_name, student_email, student_phone, student_message, confirmed = False):
    hour_uuid = str(uuid4())
    # if uuid is an int => probably lecturer_id already :D
    if type(uuid) is not int:
        lecturer_id = get_lecturer_id(uuid)
        if type(lecturer_id) is not int: return lecturer_id
    else:
        lecturer_id = uuid

    #
    
    get_db_cur().execute("""
    INSERT INTO hours(
        uuid,
        datetime,
        lecturer_rowid,
        hour_type,
        student_first_name,
        student_last_name,
        student_email,
        student_phone_number,
        student_message,
        confirmed
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", (hour_uuid, datetime, lecturer_id, hour_type, student_first_name, student_last_name, student_email, student_phone, student_message, confirmed))
    
    get_db().commit()
    return hour_uuid
    
def delete_lecturer_hour(lecturer_id, hour_uuid):
    get_db_cur().execute("SELECT * FROM hours WHERE uuid = ?", (hour_uuid, ))
    hour_to_delete = get_db_cur().fetchall()

    if len(hour_to_delete) == 0:
        return "No such hour found"

    get_db_cur().execute("DELETE FROM hours WHERE uuid = ?", (hour_uuid,))
    get_db().commit()

    return format_hour_data(hour_to_delete[0])

#  _      ______ _____ _______ _    _ _____  ______ _____   _____
# | |    |  ____/ ____|__   __| |  | |  __ \|  ____|  __ \ / ____|
# | |    | |__ | |       | |  | |  | | |__) | |__  | |__) | (___
# | |    |  __|| |       | |  | |  | |  _  /|  __| |  _  / \___ \
# | |____| |___| |____   | |  | |__| | | \ \| |____| | \ \ ____) |
# |______|______\_____|  |_|   \____/|_|  \_\______|_|  \_\_____/


# LECTUERS CREATION
def create_new_lecturer(data):
    # generate new uuid for new lecturer
    data['uuid'] = str(uuid4())

    # check if data is valid
    check, status = create_lecturer_check(data)

    if status == 400:
        return check, status
    data_tuple = check


    # insert into table
    get_db_cur().execute("""INSERT INTO lecturers(
        uuid, title_before, first_name, middle_name,
        last_name, title_after, picture_url, location,
        claim, bio, price_per_hour, contact
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", data_tuple)

    # get lecturer id
    lecturer_id = lecturer_uuid_2_id(data['uuid'])


    data['tags'] = add_tags_to_lecturer(data['tags'], lecturer_id)
    data['contact'] = json.loads(data['contact'])
    data['rowid'] = lecturer_id
    get_db().commit()
    return data, 200


def create_lecturer_check(data):
    if 'contact' not in data:
        return {'code': 400, 'message' : 'bad request'}, 400
    data['contact'] = json.dumps(data['contact'])

    # check if we have all the data required
    data_tuple = []
    for key in LECTURER_TABLE_VALUES:
        if key not in data:
            if key in LECTURER_TABLE_VALUES_MANDATORY: return {'code': 400, "message": f"missing {key}"}, 400
            data[key] = None
        elif data[key] is None and key in LECTURER_TABLE_VALUES_MANDATORY: return {'code': 400, "message": f"missing {key}"}, 400
        data_tuple.append(data[key])
    data_tuple.insert(0, data['uuid'])

    return data_tuple, 200


def create_new_tag(uuid, name):
    get_db_cur().execute("""INSERT INTO tags(uuid, name) VALUES (?, ?)""", (uuid, name))
    get_db().commit()

# LECTURERS GETS
def get_lecturer(uuid):
    # get lecturer id
    get_db_cur().execute("""SELECT *, ROWID FROM lecturers WHERE uuid= ?""", (uuid,))

    rows = get_db_cur().fetchall()

    if len(rows) == 0:
        return {"code": 404,"message": "User not found"}, 404

    return lecturer_data_from_row(rows[0]), 200

def get_lecturer_by_id(id):
    # get lecturer id
    get_db_cur().execute("""SELECT *, ROWID FROM lecturers WHERE ROWID= ?""", (id,))

    rows = get_db_cur().fetchall()

    if len(rows) == 0:
        return {"code": 404,"message": "User not found"}, 404

    return lecturer_data_from_row(rows[0]), 200

def get_lecturer_id(uuid):
    # get lecturer id
    get_db_cur().execute("""SELECT ROWID FROM lecturers WHERE uuid= ?""", (uuid,))

    rows = get_db_cur().fetchall()

    if len(rows) == 0:
        return {"code": 404,"message": "User not found"}


    return rows[0][0]

def get_lecturers():
    logger.log("GETTING")
    # gets ALL table data
    get_db_cur().execute("""SELECT *, ROWID FROM lecturers""")
    row_data = get_db_cur().fetchall()
    lecturers = []
    logger.log("......")
    logger.log(str(row_data))
    # parses each row to desired format
    for row in row_data:
        lecturers.append(lecturer_data_from_row(row))
    print(lecturers)
    logger.log("..jaoidjaoidjaodj....")
    logger.log(str(lecturers))
    logger.log("......")
    return lecturers, 200


def get_lecturers_tags(lecturer_id):
    get_db_cur().execute("""
    SELECT uuid, name FROM lecturers_tags
    JOIN tags
    ON lecturers_tags.lecturer_rowid = ? and
    tags.ROWID = lecturers_tags.tag_rowid
    """, (lecturer_id,))

    return get_db_cur().fetchall()

def get_all_locations():
    get_db_cur().execute("""SELECT DISTINCT location FROM lecturers""")
    locations_raw = get_db_cur().fetchall()

    locations = []
    for location in locations_raw:
        locations.append(location[0])

    return locations


def get_price_range():
    get_db_cur().execute("""SELECT MAX(price_per_hour), MIN(price_per_hour) FROM lecturers""")
    price_rows = get_db_cur().fetchone()
    return [price_rows[1], price_rows[0]]

def get_all_tags():
    get_db_cur().execute("""SELECT * FROM tags""")
    tags_raw = get_db_cur().fetchall()

    tags = []
    for tag in tags_raw:
        tags.append({"uuid": tag[0], "name": tag[1]})

    return tags

def get_search_lecturers_shuffle(location, tags, pay_min, pay_max):
    where = ""
    params = []

    if location is not None:
        params.append(location)
        where += " location = ? and"

    if pay_min is not None:
        params.append(pay_min)
        where += " price_per_hour >= ? and"

    if pay_max is not None:
        params.append(pay_max)
        where += " price_per_hour <= ? and"


    if tags is not None:
        if where != "":
            where = " and" + where[:-3]

        for tag in tags:
            params.append(tag)

        params.append(len(tags))

        # query thats mega
        mega_query = f"""
        SELECT DISTINCT lecturers.ROWID as l_rid FROM lecturers_tags
        JOIN lecturers
        ON lecturer_rowid = lecturers.ROWID{where}
        /*JOIN tags
        ON tags.rowid = tag_rowid*/ and
        (SELECT COUNT(*) FROM lecturers_tags
            JOIN tags
            ON lecturers_tags.lecturer_rowid = l_rid and
            lecturers_tags.tag_rowid = tags.ROWID
            and tags.uuid in ({("?," * len(tags))[:-1]})
        ) = ?
        
        """
        print(mega_query)
        get_db_cur().execute(mega_query, params)
        lecturer_rows = get_db_cur().fetchall()
    else:
        if where != "": where = f"WHERE{where[:-3]}"
        get_db_cur().execute(f"SELECT ROWID FROM lecturers {where}", params)
        lecturer_rows = get_db_cur().fetchall()

    lecturer_rids = []
    print(lecturer_rows)
    for row in lecturer_rows:
        lecturer_rids.append(row[0])

    random.shuffle(lecturer_rids)

    return lecturer_rids

# LECTURER ACTIONS
def add_tags_to_lecturer(tags, lecturer_id):
    # add all lecturer tags
    for tag_i in range(len(tags)):
        if 'uuid' not in tags[tag_i]:
            # if no uuid provided try to find this tag in the DB using name
            get_db_cur().execute("""SELECT uuid FROM tags WHERE name = ?""", (tags[tag_i]['name'],))
            tag_rows = get_db_cur().fetchall()

            # if the tag new -> create new uuid
            if len(tag_rows) == 0:
                tags[tag_i]['uuid'] = str(uuid4())
            else: # else use uuid from db
                tags[tag_i]['uuid'] = tag_rows[0][0]
        add_tag_to_lecturer(tags[tag_i]['uuid'], lecturer_id, tags[tag_i]['name'])
    return tags

def add_tag_to_lecturer(tag_uuid, lecturer_id, name_if_no_uuid = ""):
    # search for tag id using UUID
    get_db_cur().execute("""SELECT ROWID FROM tags WHERE uuid = ?""", (tag_uuid,))
    tags = get_db_cur().fetchall()

    # if nothing found -> create the tag -> get id
    if len(tags) == 0:
        create_new_tag(tag_uuid, name_if_no_uuid)
        get_db_cur().execute("""SELECT ROWID FROM tags WHERE uuid = ?""", (tag_uuid,))
        tag_id = get_db_cur().fetchone()[0]
    else: # else get id
        tag_id = tags[0][0]

    # add tag to lecturer
    get_db_cur().execute("""INSERT INTO lecturers_tags(lecturer_rowid, tag_rowid) VALUES (?, ?)""", (lecturer_id, tag_id))
    get_db().commit()


def remove_lecturer_tags(lecturer_id):
    get_db_cur().execute("""DELETE FROM lecturers_tags WHERE lecturer_rowid = ?""", (lecturer_id,))

def update_lecturer(uuid, new_data):
    # get lecturer id
    lecturer_id = lecturer_uuid_2_id(uuid)

    if lecturer_id is None:
        return {"code": 404,"message": "User not found"}, 404

    if 'tags' in new_data:
        remove_lecturer_tags(lecturer_id)

        new_data['tags'] = add_tags_to_lecturer(new_data['tags'], lecturer_id)

    # parse contacts
    if 'contact' in new_data:
        new_data['contact'] = json.dumps(new_data['contact'])

    # add all changed values to be ? into mega query
    value_pairs = ()
    qmarks = ""

    for key in new_data.keys():
        if key in LECTURER_TABLE_VALUES:
            qmarks += f"{key} = ?, "
            #value_pairs += (key,)
            value_pairs += (new_data[key],)


    # add lecturer_id for search
    value_pairs += (lecturer_id,)

    print(value_pairs)
    print(qmarks)

    if qmarks != "":
        qmarks = qmarks[:-2]

        get_db_cur().execute(f"""
        UPDATE lecturers
        SET {qmarks}
        WHERE ROWID = ?""", value_pairs)

        get_db().commit()

    return get_lecturer(uuid)


def delete_lecturer(uuid):
    # get lecturer id
    lecturer_id = lecturer_uuid_2_id(uuid)

    if lecturer_id is None:
        return {"code": 404,"message": "User not found"}, 404

    remove_lecturer_tags(lecturer_id)

    get_db_cur().execute("""DELETE FROM lecturers WHERE ROWID = ?""", (lecturer_id,))
    get_db().commit()

    return {"code": 204, "message": "úspěšně smazán"}, 204


def lecturer_uuid_2_id(uuid):
    # get lecturer id
    get_db_cur().execute("""SELECT ROWID FROM lecturers WHERE uuid = ?""", (uuid,))
    lecturer_id = get_db_cur().fetchall()

    if len(lecturer_id) == 0:
        return None

    return lecturer_id[0][0]


def lecturer_data_from_row(row):
    # uuid
    lecturer_data = {'uuid': row[0]}

    # table values
    for i in range(len(LECTURER_TABLE_VALUES)):
        lecturer_data[LECTURER_TABLE_VALUES[i]] = row[i + 1]

    # parse contact json
    lecturer_data['contact'] = json.loads(lecturer_data['contact'])

    # tags
    lecturer_data['tags'] = []
    for tag in get_lecturers_tags(row[-1]):
        lecturer_data['tags'].append({"uuid" : tag[0], "name" : tag[1]})

    return lecturer_data


def search_lecturers(row_ids=None):
    if row_ids is None:
        row_ids = []
    mega_query = f"""
    SELECT uuid, title_before, first_name, middle_name, last_name, title_after, picture_url, location, claim, bio, price_per_hour, contact, lecturers.ROWID as l_rid FROM lecturers
    WHERE ROWID in ({("?," * len(row_ids))[:-1]})
    """

    get_db_cur().execute(mega_query, row_ids)
    lecturer_rows = get_db_cur().fetchall()

    lectures = []


    sorted_ids = sorted(row_ids)

    for i in range(len(row_ids)):
        lectures.append(lecturer_data_from_row(lecturer_rows[sorted_ids.index(row_ids[i])]))

    return lectures


# COMMANDS
@click.command('init-db')
@with_appcontext
def init_db_command():
    """
    Definujeme příkaz příkazové řádky
    """
    init_db()
    click.echo('Initialized the database.')


def init_app(app):
    app.teardown_appcontext(close_db)
    app.teardown_appcontext(close_db_cur)
    app.cli.add_command(init_db_command)

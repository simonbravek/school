import smtplib
from email.message import EmailMessage
from email.mime.text import MIMEText

APP_PASSWORD = "ogie jhrr xpmj fasu"
EMAIL_SEARCH_REGEX = ".+@.+\..+"
PHONE_SEARCH_REGEX = "\+?\d+[\s|\d]+"

def send_email_gmail(subject, html, destination):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()

    server.login('noreply.tda@gmail.com', APP_PASSWORD)

    msg = EmailMessage()

    message = MIMEText(html, "html")
    msg.set_content(message)
    msg['Subject'] = subject
    msg['From'] = 'noreply.tda@gmail.com'
    msg['To'] = destination
    server.send_message(msg)
    print("SENT!")


def get_lecturer_fullname(lecturer):
    names = [lecturer['title_before'], lecturer['first_name'], lecturer['middle_name'], lecturer['last_name'], lecturer['title_after']]

    removed_count = 0
    for i in range(len(names)):
        if names[i - removed_count] is None or names == "":
            names.pop(i - removed_count)
            removed_count += 1

    return " ".join(names)


if __name__ == "__main__":
    pass
let weekday_2_short_name = ["Po", "Út", "St", "Čt", "Pá", "So", "Ne"]

class Calendar {

    constructor() {
        this.calendar_grid = document.getElementById("calendar_grid")
        this.current_calendar_view = "none"
        this.current_calendar_start_date = null

        this.adding_new_event = false
        this.new_event_el = null
        this.new_event_end_pos = 0
        this.new_event_start_pos = 0
    }


    render_calendar_dates(){
        this.render_week(this.get_monday(new Date()))
    }

    render_week(first_date){
        document.getElementById("calendar_title").innerHTML = first_date.toString()

        this.current_calendar_start_date = first_date
        this.current_calendar_view = "week"
        this.calendar_grid.innerHTML = ""
        this.calendar_grid.style.display = "flex";
        this.calendar_grid.style.flexDirection = "column";

        // days
        let day_div = document.createElement("div")
        day_div.style.display = "flex";
        day_div.style.width = "100%";
        day_div.id = "calendar_day_div"
        this.calendar_grid.appendChild(day_div);

        //hours
        let hour_div = document.createElement("div")
        hour_div.style.display = "flex";
        hour_div.style.width = "100%";
        hour_div.id = "calendar_hour_div"
        hour_div.style.flexGrow = "1";
        this.calendar_grid.appendChild(hour_div)

        // hour column
        day_div.innerHTML = "<div style='width: 30px; min-width: 30px; background: var(--sunglow)'></div>"

        let hours_display = document.createElement("div")
        hours_display.style.width = "30px"
        hours_display.style.minWidth = "30px"
        hours_display.style.background = "var(--sunglow)"
        hours_display.style.display = "flex"
        hours_display.style.flexDirection = "column"
        hour_div.appendChild(hours_display)

        // fill in week days
        for (let i = 0; i < 7; i++){
            // days
            let date = new Date(new Date(first_date).setDate(first_date.getDate() + i));

            let day_el = document.createElement("div")
            day_el.innerHTML = `
                <h3>${date.getDate()}   <i>${weekday_2_short_name[i]}</i></h3>
            `
            day_el.className = "calendar_tile week_tile"
            day_div.appendChild(day_el)

            // hour containers
            let hour_cont = document.createElement("div")
            hour_cont.className = "calendar_tile week_tile";

            hour_div.appendChild(hour_cont)
        }

        // fill in day hours
        for (let i = 0; i < 15; i ++){
            let hour_label = document.createElement("div");
            hour_label.className = "hour_label"
            hours_display.appendChild(hour_label)
            hour_label.innerHTML = "<span>" + (i + 7).toString() + "<span style='font-size: 10px;'>:00</span></span>"

            for (let x = 1; x < hour_div.children.length; x++){
                let hour_block = document.createElement("div")
                hour_block.className = "hour_block"
                //hour_block.innerText = "12:00"
                if (i === 0 || i === 14) { hour_block.className += " disabled disabledrow" }
                hour_div.children[x].appendChild(hour_block);

                let this_class = this
                hour_block.addEventListener("pointerdown", ()=>{this_class.hour_block_down(hour_block)})
                hour_block.addEventListener("pointerover", () => {this_class.adding_event_update(hour_block)})
                hour_block.addEventListener("pointerup", () => {this_class.hour_block_up(hour_block)})
            }
        }
    }

    change_week(first_date){
        document.getElementById("calendar_title").innerHTML = first_date.toString()
        this.current_calendar_start_date = first_date

        // fill in week days
        for (let i = 0; i < 7; i++){
            // days
            let date = new Date(new Date(first_date).setDate(first_date.getDate() + i));

            let day_el = document.getElementById("calendar_day_div").children[i + 1]
            day_el.innerHTML = `
                <h3>${date.getDate()}   <i>${weekday_2_short_name[i]}</i></h3>
            `
        }

        let hour_div = document.getElementById("calendar_hour_div")

        // fill in day hours
        for (let i = 0; i < 15; i ++){
            for (let x = 1; x < hour_div.children.length; x++){
                let hour_block = hour_div.children[x].children[i]
                hour_block.innerHTML = ""
                hour_block.className = "hour_block"
                if (i === 0 || i === 14) { hour_block.className += " disabled disabledrow" }
            }
        }
    }

    render_events(events){
        let start_date = this.current_calendar_start_date
        let end_date = null
        if (this.current_calendar_view === "week") { end_date = new Date(new Date(this.current_calendar_start_date).setDate(this.current_calendar_start_date.getDate() + 6)) }

        start_date.setHours(0)
        end_date.setHours(23)

        let hour_div = document.getElementById("calendar_hour_div")

        for (let i = 0; i < events.length; i++){
            let event = events[i]

            if (start_date < event['from'] && event['from'] < end_date){
                if (this.current_calendar_view === "week"){
                    // add lesson blob
                    let day_diff = event['from'].getDate() - start_date.getDate()
                    let hour_diff = event['to'].getHours() - event['from'].getHours()



                    let day_column = hour_div.children[day_diff + 1]
                    let start_hour_idx = event['from'].getHours() - 7

                    // disable calendar button
                    for (let x = 0; x < hour_diff; x++){
                        day_column.children[start_hour_idx + x].className += " disabled"
                    }

                    let event_block = document.createElement("div")
                    event_block.className = "event_block"
                    event_block.style.height = "calc(" + (100 * hour_diff).toString() + "% - 30px)";
                    day_column.children[start_hour_idx].appendChild(event_block)
                }
            }
        }
    }

    calendar_move(value){
        if (this.current_calendar_view === "week"){
            this.change_week(this.get_monday(new Date(new Date(this.current_calendar_start_date).setDate(this.current_calendar_start_date.getDate() + 7 * value))))
        }
    }

    // HELPERS
    get_monday(d) {
        d = new Date(d);
        let day = d.getDay(),
            diff = d.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
        return new Date(d.setDate(diff));
    }

    hour_block_down(el){
        if (el.className.includes("disabled")) { return }
        this.adding_new_event = true

        let event_block = document.createElement("div")
        event_block.className = "event_block"
        this.new_event_end_pos = get_child_idx(el)
        this.new_event_start_pos = get_child_idx(el)
        event_block.style.height = "calc(" + (100).toString() + "% - 30px)";
        event_block.style.pointerEvents = "none";
        el.appendChild(event_block)
        this.new_event_el = event_block
    }

    adding_event_update(el){
        if (this.adding_new_event){
            let diff = Math.max(get_child_idx(el) - this.new_event_start_pos + 1, 1)

            let column = this.new_event_el.parentNode.parentNode
            // block row if disabled block in the way
            for (let i = this.new_event_start_pos; i < this.new_event_start_pos + diff; i++){
                this.new_event_end_pos = i
                if (column.children[i].className.includes("disabled")){
                    diff = i - this.new_event_start_pos
                    break
                }
            }

            this.new_event_el.style.height = "calc(" + (100 * diff).toString() + "% - 30px)";
        }
    }

    hour_block_up(el){
        this.adding_new_event = false

        if (this.new_event_el !== null){
            const new_event = new CustomEvent("new_event", {
                detail: {
                    name: "dog",
                },
            });
            this.calendar_grid.dispatchEvent(new_event);
        }
    }

    confirm_new_event(){
        let column = this.new_event_el.parentNode.parentNode
        // block row if disabled block in the way
        for (let i = this.new_event_start_pos; i < this.new_event_end_pos + 1; i++){
            column.children[i].className += " disabled"
        }
        this.new_event_el = null
    }

    dont_confirm_new_event(){
        this.new_event_el.remove()
        this.new_event_el = null
    }


}

function get_child_idx(child){
    return Array.from(child.parentNode.children).indexOf(child)
}

let calendar = new Calendar()
calendar.render_calendar_dates()
calendar.render_events(
    [
        {"from": new Date("2024-02-19T10:00"), "to": new Date("2024-02-19T11:00")},
        {"from": new Date("2024-02-20T15:00"), "to": new Date("2024-02-20T20:00")}
    ]
)

// EXAMPLE CONFIRM
calendar.calendar_grid.addEventListener("new_event", () => {
    if (confirm("Potvrzujete?")){
        calendar.confirm_new_event()
    } else {
        calendar.dont_confirm_new_event()
    }
})

let calendar_mode = ""
let calendar_length = 0
let weekday_2_short_name = ["Po", "Út", "St", "Čt", "Pá", "So", "Ne"]
let mini_calendar_grid = document.getElementById("mini_calendar_grid")
let current_first_day = null


// CREATES WEEK CALENDAR ELEMENTS (NEEDS TO BE CALLED ONLY ONCE)
function create_week_calendar(week_length){
    mini_calendar_grid.innerHTML = ""
    calendar_length = week_length
    calendar_mode = "week"

    //days holder
    let day_div = document.createElement("div")
    day_div.style.display = "grid";
    day_div.style.width = "100%";
    day_div.style.gap = "10px"
    day_div.style.margin = "10px 0";
    day_div.style.gridAutoFlow = "column";
    day_div.style.gridAutoColumns = "1fr";
    day_div.id = "mini_calendar_day_div"
    mini_calendar_grid.appendChild(day_div);


    for (let i = 0; i < week_length; i++){
        let day_column = document.createElement("div")
        day_column.className = "calendar_tile week_tile";

        day_div.appendChild(day_column)

        for (let h = 0; h < 14; h++){
            let column_blob = document.createElement("div")
            column_blob.className = "column_blob"
            day_column.appendChild(column_blob)

            if (h === 0) { column_blob.className += " day_blob" }
            else {
                let hour_text = (h + 7).toString() + ":00"
                column_blob.innerText = hour_text

                add_hover_events(column_blob, hour_text)
            }
        }
    }
}

// RE RENDERS ALL THE TEXTS IN THE CALENDAR (ONLY FOR WEEK MODE)
function render_week_calendar(first_day, week_length = 7){
    if (calendar_mode !== "week" || week_length !== calendar_length){ create_week_calendar(week_length) }
    let day_div = document.getElementById("mini_calendar_day_div")
    current_first_day = first_day
    let last_day = null

    let now_date = new Date(Date.now());
    console.log(now_date)
    now_date.setHours(0)
    now_date.setMinutes(0)
    now_date.setSeconds(0)

    for (let d = 0; d < week_length; d++) {
        let date = new Date(new Date(first_day).setDate(first_day.getDate() + d));
        date.setHours(0)
        date.setMinutes(0)
        date.setSeconds(0)
        let today = Math.abs(date.getTime() - now_date.getTime()) < 3000
        let disabled_date = now_date >= date || today

        for (let h = 0; h < 14; h++) {
            let column_blob = day_div.children[d].children[h]
            column_blob.className = "column_blob"

            if (h === 0) {
                column_blob.innerHTML = `<h3>${date.getDate()}   <i>${weekday_2_short_name[(date.getDay() + 6) % 7]}</i></h3>`
                column_blob.className += " day_blob"
                if (today) {
                    column_blob.className += " today"
                }
            }
            else{
                let hour_text = (h + 7).toString() + ":00"
                column_blob.innerText = hour_text
                column_blob.style.display = "grid"
                // disabling
                if (disabled_date) { disable_column_blob(column_blob) }
                // enabled state
                else {
                    let hour_time = new Date(date)
                    hour_time.setHours(h + 7)
                    hour_time.setMinutes(0)
                    hour_time.setSeconds(0)
                    column_blob.replaceWith(column_blob.cloneNode(true));
                    column_blob = day_div.children[d].children[h]

                    add_hover_events(column_blob, hour_text)

                    if (INTERATION_TYPE === "booking" && !column_blob.className.includes("disabled")) {
                        column_blob.addEventListener("click", () => {
                                if (column_blob.className.includes("disabled")) {
                                    return
                                }
                                setup_popup_menu(hour_time,
                                    () => {
                                        submit_reservation_form(hour_time)
                                    })
                            }
                        )
                    } else if (INTERATION_TYPE === "lecturer"){
                        column_blob.addEventListener("click", () => {
                                if (column_blob.className.includes("booked") || column_blob.className.includes("blocked")) {return}
                                block_lecturer_hour(hour_time,
                                    (r) => {
                                        if (r === "ok"){
                                            render_week_calendar(first_day, calendar_length)
                                        }
                                })
                            }
                        )
                    }
                }
            }
        }
        last_day = date
    }

    // calendar title
    document.getElementById("mini_calendar_title").innerHTML = `${first_day.getDate()}. ${first_day.getMonth() + 1}. - ${last_day.getDate()}. ${last_day.getMonth() + 1}. <i>${first_day.getFullYear()}</i>`

    // RENDERING EVENTS
    let start_date = new Date(first_day)
    let end_date = new Date(new Date(first_day).setDate(first_day.getDate() + 6))


    start_date.setHours(0)
    end_date.setHours(23)


    // send api request and pass on function that is called when request processed
    get_lecturer_hours(start_date, end_date, (events) => {
        let lecturer_itype = INTERATION_TYPE === "lecturer"
        for (let i = 0; i < events.length; i++){
            let event = events[i]
            event['time'] = new Date(event['time'])

            if (start_date < event['time'] && event['time'] < end_date){
                let day_diff = Math.floor((event['time'].getTime() - start_date.getTime()) / (1000 * 3600 * 24))
                let hour = event['time'].getHours() - 7
                let column_blob = day_div.children[day_diff].children[hour]

                if (lecturer_itype){
                    // IF LECTURE IS NOT LECTURER BLOCKED
                    if (event['phone'] !== "-"){
                        //
                        let image_src = (event['type'] === 1) ? "globe2.svg" : "location-small.svg"
                        // warning icon
                        if (!event['confirmed']){
                            image_src = "warning.svg"
                        }

                        // hour icon
                        column_blob.innerHTML = `
    ${event['time'].getHours()}:00<img src="../static/images/${image_src}" class="column_blob_icon">
                        `


                        column_blob.className += " booked nohovertext"

                        column_blob.addEventListener("click", () => {
                            setup_popup_menu(()=>{
                                document.getElementById("cancel_hour_submit").innerHTML = '<div id="loading_circle" class="loading_circle_but">'
                                delete_lecturer_hour(event['uuid'],
                                    (r) => {
                                        document.getElementById("cancel_hour_submit").innerHTML = 'Zrušit rezervaci'
                                        if (r === "deleted"){
                                            close_popup_menu_func()
                                            render_week_calendar(first_day, calendar_length)
                                        }
                                    })
                            }, event)
                        })
                    } else {
                        column_blob.className += " blocked"

                        column_blob.addEventListener("click", () => {
                            delete_lecturer_hour(event['uuid'],
                                (r) => {
                                    if (r === "deleted"){
                                        render_week_calendar(first_day, calendar_length)
                                    }
                            })
                        })

                    }
                } else {
                    disable_column_blob(column_blob)
                }
            }
        }
    })
}

// CALENDAR HELPERS
function disable_column_blob(el){
    if (HIDE_DISABLED){
        //el.style.display = "none" // HIDE
        // VYPLMLCKOVAT
        el.innerText = "-"
        el.className += " disabled nohoveranim nohovertext"
    } else {
        //el.className += " disabled"
        el.innerText = "-"
        el.className += " disabled nohoveranim nohovertext"
    }
}

function add_hover_events(column_blob, hour_text){
    // enter mouse
    column_blob.addEventListener("mouseenter", () => {
        if (!column_blob.className.includes("nohovertext") && !column_blob.className.includes("blocked")){
            column_blob.innerText = BUTTON_ACTION_TEXT
        } else if (column_blob.className.includes("blocked")){ // WARNING HARD CODED HOVER TEXT
            column_blob.innerText = "Vrátit"
        }
    })

    // out mouse
    column_blob.addEventListener("mouseout", () => {
        if (!column_blob.className.includes("nohovertext")){
            column_blob.innerText = hour_text
        }
    })
}

function get_monday(d) {
    d = new Date(d);
    let day = d.getDay(),
        diff = d.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    return new Date(d.setDate(diff));
}

// GENERAL CALENDAR BEHAVIOUR
function move_calendar(value){
    if (calendar_mode === "week"){
        let first_day = null
        if (calendar_length === 7){
            first_day = get_monday(new Date(new Date(current_first_day).setDate(current_first_day.getDate() + 7 * value)))
        } else {
            first_day = new Date(new Date(current_first_day).setDate(current_first_day.getDate() + calendar_length * value))
        }
        render_week_calendar(first_day, calendar_length)
    }
}

// HELPER UI FUNCTIONS
function submit_reservation_form(hour_time){
    // get data
    let data = {
        "Email": document.getElementById("reserve_email").value,
        "Jméno": document.getElementById("reserve_fname").value,
        "Příjmení": document.getElementById("reserve_lname").value,
        "Telefon": document.getElementById("reserve_phone").value
    }


    let message = document.getElementById("reserve_message").value

    // js detect if info is stupid
    let report_message = ""

    for (let i = 0; i < Object.keys(data).length; i++){
        if (Object.values(data)[i] === ""){
            report_message += Object.keys(data)[i] + " chybí; "
        }
    }

    console.log(report_message)

    if (report_message !== ""){
        document.getElementById("reserve_error_info").innerHTML = report_message
        return
    }

    document.getElementById("reserve_submit").innerHTML = '<div id="loading_circle" class="loading_circle_but">'

    // send api call
    post_lecturer_hour(
        {
            "uuid": CALENDAR_LECTURER_UUID,
            "datetime": hour_time,
            "hour_type": document.getElementById("option_online").checked ? 1 : 2,
            "first_name": data['Jméno'],
            "last_name": data['Příjmení'],
            "email": data['Email'],
            "phone": data['Telefon'],
            "message": message
        },
        (r) => {
            if (r === "ok"){
                document.getElementById("reserve_form").style.display = "none"
                let success = document.getElementById("reserve_success")
                render_week_calendar(current_first_day, calendar_length)
                document.getElementById("reserve_title").innerText = "Potvrďte rezervaci"
                popup_resize(popup)
                success.style.display = "grid"
                success.innerHTML = `
<i>Na ${data['Email']} jsme poslali email na potvrzení.<br>Rezervace je uložena, do 1 hodiny potvrďte, jinak bude vrácena do oběhu.</i> `
            } else {
                document.getElementById("reserve_error_info").innerHTML = r
            }
            document.getElementById("reserve_submit").innerHTML = 'Rezervovat'
        }
    )
}

// HELPER API FUNCTIONS
function post_lecturer_hour(data, end_event = null){
    const response = new XMLHttpRequest();
    response.open("POST", "/api/hour");
    response.setRequestHeader('Content-Type', "application/json");
    response.send(JSON.stringify(
        data
    ));

    if (end_event !== null){
        response.onload = () =>
        {
            end_event(response.response)
        }
    }

}

function block_lecturer_hour(datetime, end_event = null){
    const response = new XMLHttpRequest();
    response.open("POST", "/api/blockhour");
    response.setRequestHeader('Content-Type', "application/json");
    response.send(JSON.stringify(
        {
            "datetime": datetime
        }
    ));

    if (end_event !== null){
        response.onload = () =>
        {
            end_event(response.response)
        }
    }

}

function delete_lecturer_hour(lecture_uuid, end_event = null){
    const response = new XMLHttpRequest();
    response.open("POST", "/api/cancelhour");
    response.setRequestHeader('Content-Type', "application/json");
    response.send(JSON.stringify(
        {
                "uuid": lecture_uuid,
                "message": document.getElementById("cancel_message").value
            }
    ));

    if (end_event !== null){
        response.onload = () =>
        {
            end_event(response.response)
        }
    }

}

function get_lecturer_hours(first_day, end_day, end_event){
    const response = new XMLHttpRequest();
    response.open("POST", "/api/gethours");
    response.setRequestHeader('Content-Type', "application/json");
    response.send(JSON.stringify(
        {
            "uuid": CALENDAR_LECTURER_UUID,
            "start_date": first_day,
            "end_date": end_day
        }
    ));

    response.onload = (e) => {
        end_event(JSON.parse(response.response));
    }
}


// Function to update height and width
function mini_calendar_resize() {
    if (window.innerWidth < 700 && calendar_length !== 2){
        render_week_calendar(new Date(), 2)
    } else if(window.innerWidth >= 700 && calendar_length !== 7){
        render_week_calendar(get_monday(new Date()), 7)
    }
}

// Add event listener for window resize
window.addEventListener('resize', mini_calendar_resize);
mini_calendar_resize()
//


var indexes = {}
var shuffle = []
var page_nav = 0
var card_number = 17

function search_but(){
    let loc_val = document.getElementById("search_location").value
    if (loc_val === "" || loc_val === "Vše") { loc_val = null }
    let tags = get_selected_tags_uuids()
    if (tags.length === 0) { tags = null; }

    const pay_values = document.getElementById("pay_range").value.split(",")
    let min_pay = Number(pay_values[0])
    let max_pay = Number(pay_values[1])

    search(loc_val, tags, min_pay, max_pay)
}

function search(location, tags, pay_min, pay_max){
    let data = {
        "location" : location,
        "tags":tags,
        "pay_min": pay_min,
        "pay_max":pay_max,
    }

    const response = new XMLHttpRequest();
    response.open("POST", "/api/search");
    response.setRequestHeader('Content-Type', "application/json");
    response.send(JSON.stringify(data));

    response.onload = (e) => {
        let data = JSON.parse(response.response)
        console.log(data)
        shuffle = data['shuffle']
        page_nav = 0

        populate_cards(data['search'])
    }
}

function search_page(){
    page = shuffle.slice(page_nav * card_number, Math.min(shuffle.length, page_nav * card_number + card_number))

    let data = {
        'rowids': page
    }

    const response = new XMLHttpRequest();
    response.open("POST", "/api/getpage");
    response.setRequestHeader('Content-Type', "application/json");
    response.send(JSON.stringify(data));

    response.onload = (e) => {
        let data = JSON.parse(response.response)
        console.log(data)
        populate_cards(data)
        window.location.href = '#cards'

    }
}

function get_search_utils() {
    const response = new XMLHttpRequest();
    response.open("GET", "/api/searchutils");
    response.send();

    response.onload = (e) => {
        indexes = JSON.parse(response.response);
        setup_indexes()
        setup_search_ui()
        search_but()
    }
}

get_search_utils()

function setup_indexes(){
    indexes['locations'].unshift("Vše")

    indexes['tags_dict'] = {}
    for (let i = 0; i < indexes['tags'].length; i++){
        indexes['tags_dict'][indexes['tags'][i]['name']] = indexes['tags'][i]['uuid']
    }
}

function setup_search_ui(){
    // location
    new SearchDropDown(document.getElementById("location_drop"), document.getElementById("search_location"), indexes['locations'])
    // tags
    const tag_drpdwn = new SearchDropDown(document.getElementById("tag_drop"), document.getElementById("search_tag"), Object.keys(indexes['tags_dict']), true, true)

    document.getElementById("tag_drop").addEventListener("input_submit", (e) => {
        add_tag_to_tag_list(e.detail.input, document.getElementById("tag_list"), tag_drpdwn)
        tag_drpdwn.used_options.push(input_2_pseudo_val(e.detail.input))
    })

    // price range

    let min_pay = Math.floor(indexes['price_range'][0] / 50) * 50
    let max_pay = Math.ceil(indexes['price_range'][1] / 50) * 50

    document.getElementById("pay_range").value = min_pay.toString() + "," + max_pay.toString()
    // setup slider
    $('.range-slider').jRange({
        from: min_pay,
        to: max_pay,
        step: 50,
        scale: [min_pay, max_pay],
        format: '%s',
        width: 300,
        showLabels: true,
        isRange : true,
        theme: "theme-blue",
        ondragend: function () { search_but() },
        onbarclicked: function () { search_but() }
    });

    // auto search
    document.getElementById("tag_drop").addEventListener("input_submit", (e) => {
        search_but()
    })

    document.getElementById("location_drop").addEventListener("input_submit", (e) => {
        search_but()
    })
}

function get_selected_tags_uuids(){
    let out = []
    let tag_els = document.getElementById("tag_list").children
    for (let i = 0; i < tag_els.length; i++) {
        if (tag_els[i].id === "tag_drop" || tag_els[i].style.opacity === "0") continue
        out.push(indexes.tags_dict[tag_els[i].title])
    }
    return out
}


// simon
function removeElementsByClass(className){
    const elements = document.getElementsByClassName(className);
    while(elements.length > 0){
        elements[0].parentNode.removeChild(elements[0]);
    }
}


function populate_cards(data){
    //document.getElementById("cards").innerHTML = ""


    //simon
    removeElementsByClass('white_card')
    removeElementsByClass('navigator_card')

    for (let i = 0; i < data.length; i++){
        document.getElementById("cards").appendChild(create_card(data[i]))
    }  

    if (shuffle.length > card_number){
        document.getElementById("cards").appendChild(create_page_navigator())
    }  

    if (document.getElementById("cards").innerHTML === ""){
        document.getElementById("cards").innerHTML = "<p class='no_results'>Omlouváme se, žádné výsledky.</p>"
    }

}
function create_card(lecturer){
    let card = document.createElement("a")
    card.className = "card white_card"
    card.style.position = "relative"
    card.href = "/lecturer/" + lecturer.uuid
    let name_split = [lecturer.title_before, lecturer.first_name, lecturer.middle_name, lecturer.last_name, lecturer.title_after]
    let full_name = ""

    for (let i = 0; i < name_split.length; i++){
        if (name_split[i] !== null && name_split[i] !== "" && name_split[i] !== "null") {
            full_name += name_split[i] + " "
        }
    }
    full_name.trim()


    if (lecturer.picture_url === "https://picsum.photos/200"){
        lecturer.picture_url += "?t=" + Math.random().toString()
    }

    tags = ""

    for (let i = 0; i < lecturer.tags.length; i++){
        tags += `<div class="tag">${lecturer.tags[i].name}</div>`
    }

    card.innerHTML = `
<img src='${lecturer.picture_url}' class="circle_mask loading_background" style="width: 200px; height: 200px"> <!--style="width: 0px; height: 100px"-->
<h1>${full_name}</h1>
<p class="clear_text">
${lecturer.claim}
</p>
<div class="card-tag-list">
${tags}
</div>
<div class="loc_container">
<img src="../static/images/location-pin.svg" style="height: 2rem; width: 2rem; margin-right: 10px; float: left;">
<span style="float: left">${lecturer.location}</span>
<span style="float: right">${lecturer.price_per_hour} kč/h</span>
</div>`
    return card
}

function create_page_navigator(){
    let nav = document.createElement("span")
    nav.className = "navigator_card"

    next_availabe = shuffle.length > (page_nav * card_number + card_number)
    prev_availabe = page_nav > 0

    nav.innerHTML = `
<span class="yel_but ${prev_availabe ? "" : "disabled"}" onclick="${prev_availabe ? "javascript:page_nav -= 1; search_page();" : ""}">PŘEDEŠLÉ</span>
<span class="yel_but ${next_availabe ? "" : "disabled"}" onclick="${next_availabe ? "javascript:page_nav += 1; search_page();" : ""}">DALŠÍ</span>
`
    return nav
}


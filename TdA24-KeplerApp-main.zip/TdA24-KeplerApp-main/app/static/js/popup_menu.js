// Function to update height and width
function popup_resize(popup) {
    if (popup.children[0].offsetHeight > window.innerHeight && (popup.style.alignContent === "center" || popup.style.alignContent === "")){
        popup.style.alignContent = "start"
    } else if(popup.children[0].offsetHeight < window.innerHeight && (popup.style.alignContent === "start" || popup.style.alignContent === "")){
        popup.style.alignContent = "center"
    }
}
// Add event listener for window resize
window.addEventListener('resize', () => {
    popup_resize(popup)
});
setTimeout(() => {
    popup_resize(popup)
}, 1000)
//
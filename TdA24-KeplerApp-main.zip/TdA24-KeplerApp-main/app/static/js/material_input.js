material_textfields = document.getElementsByClassName("material_textfield")

for (let i = 0; i < material_textfields.length; i++){
    let input = material_textfields[i].getElementsByTagName("input")

    // also detect text areas
    if (input.length > 0){
        input = input[0]
    } else{
        input = material_textfields[i].getElementsByTagName("textarea")[0]
    }
    //

    input.addEventListener("input", () => {
        input.setAttribute("value", input.value);
    })
}
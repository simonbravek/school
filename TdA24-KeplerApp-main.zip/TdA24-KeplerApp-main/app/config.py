import os
from datetime import timedelta

class BaseConfig(object):
    """Base configuration."""

    # main config
    SECRET_KEY = 'MAKE KEY SECRET'
    PERMANENT_SESSION_LIFETIME = timedelta(days=1)
    DEBUG = False
    BCRYPT_LOG_ROUNDS = 13
    WTF_CSRF_ENABLED = True
    DEBUG_TB_ENABLED = False
    DEBUG_TB_INTERCEPT_REDIRECTS = False
    ADMIN_USERNAME = "TdA"
    ADMIN_PASSWORD = "d8Ef6!dGG_pv"